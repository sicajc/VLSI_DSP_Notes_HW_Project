/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: filterSystem_types.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 31-Mar-2023 20:58:47
 */

#ifndef FILTERSYSTEM_TYPES_H
#define FILTERSYSTEM_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for filterSystem_types.h
 *
 * [EOF]
 */
