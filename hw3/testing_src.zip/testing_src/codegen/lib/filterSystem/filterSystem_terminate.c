/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: filterSystem_terminate.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 31-Mar-2023 20:58:47
 */

/* Include Files */
#include "filterSystem_terminate.h"
#include "filterSystem.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void filterSystem_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for filterSystem_terminate.c
 *
 * [EOF]
 */
